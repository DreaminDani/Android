package net.desandoval.apps.schedule.dummy;

/**
 * Created by Daniel on 18/11/2014.
 */
public class DayItem {
}

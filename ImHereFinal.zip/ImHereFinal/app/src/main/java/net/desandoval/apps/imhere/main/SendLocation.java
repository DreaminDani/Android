package net.desandoval.apps.imhere.main;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import net.desandoval.apps.imhere.R;
import net.desandoval.apps.imhere.contacts.Contact;
import net.desandoval.apps.imhere.contacts.CustomContactsAdapter;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Daniel on 9/12/2014.
 */
public class SendLocation extends ActionBarActivity {
    final String TAG = CustomContactsAdapter.class.getSimpleName();

    private List<Contact> mContacts;
    private List<Contact> storedContacts;
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_location);

        mRecyclerView = (RecyclerView) findViewById(R.id.SendLocationRecyclerList);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        // get contacts from Parse
        storedContacts = new ArrayList<>();
        getContactsFromParse();
        mContacts = storedContacts;
        if (mContacts == null) {
            mContacts = new ArrayList<>();
        }

        CustomContactsAdapter adapter = new CustomContactsAdapter(mContacts, this);

        mRecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void getContactsFromParse() {
        ParseQuery<ParseObject> query = ParseQuery.getQuery("CustomContacts");
        query.whereEqualTo("user", ParseUser.getCurrentUser());
        query.findInBackground(new FindCallback<ParseObject>() {

            @Override
            public void done(List<ParseObject> parseObjects, ParseException e) {
                if (e == null) {
                    for (int i = 0; i < parseObjects.size(); i++) {
                        ParseObject obj = parseObjects.get(i);
                        Contact storedContact = new Contact(obj.getString("name"), obj.getString("number"), obj.getString("id"));
                        storedContacts.add(storedContact);
                    }
                } else {
                    Log.d("Parse Error", "Could not retrieve stored markers for deletion - markers not delete from parse");
                }
            }
        });
    }
}
